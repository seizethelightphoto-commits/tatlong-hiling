import React from 'react'
import TatlongHilingWishTree from './TatlongHilingWishTree.jsx'

export default function App(){
  return <TatlongHilingWishTree />
}