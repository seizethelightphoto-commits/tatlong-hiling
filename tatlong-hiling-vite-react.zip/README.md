# Tatlong Hiling — Wish Tree (Vite + React)

## Quick start (no terminal on your machine)
1. Upload this folder to a **new GitHub repo**.
2. In **Netlify → Import from Git**, select your repo.
3. Build command: `npm run build`  •  Publish directory: `dist`
4. After deploy, replace `public/tree-illustration.png` with your artwork (same filename).
5. The TikTok embed is set to: https://www.tiktok.com/@vvink_ph/video/7543960600209231112

## Local dev (if you have Node)
npm install
npm run dev

## Build
npm run build